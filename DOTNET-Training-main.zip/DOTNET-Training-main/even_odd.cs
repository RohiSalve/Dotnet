using System;
namespace EvenOdd
{
    
        class even_odd{
    
    static void Main(string[] args)
    {
        int a=3;
        if(a%2==0){
            Console.WriteLine("Even");
        }
        else{
            Console.WriteLine("Odd");
        }
    }
    }
    
    
}
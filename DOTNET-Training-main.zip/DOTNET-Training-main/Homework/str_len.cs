using System;

class str_len
{
    static void Main()
    {
        string input = "Hello World";
        int length = input.Length;

        Console.WriteLine("String: " + input);
        Console.WriteLine("Length of string: " + length);
    }
}

using System;
namespace even_odd{
    class even_odd{
        static void Main(string[] args){
            int a=2,b=3,c;

            c=a;
            a=b;
            b=c;
            Console.WriteLine(a);
            Console.WriteLine(b);
        }
    }
}
using System;
class str_concat{
    public static void Main(string[] args){
        string a="Siddhi";
        string b="Amale";
        Console.WriteLine(a+b);
        Console.WriteLine(string.Concat(a,b));
    }
}
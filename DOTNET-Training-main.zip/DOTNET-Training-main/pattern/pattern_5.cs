using System;
namespace pattern5{
    class pattern5{
        static void Main(string[] args){
            int n = 5;
            for(int i=1;i<=n;i++){
                for(int j=1;j<=i;j++){
                    Console.Write("*");
                }
                Console.WriteLine();
            }


        }
    }
}
using System;
namespace pattern6{
    class pattern6{
        static void Main(string[] args){
            int n = 5;
            for(int i=1;i<=n;i++){
                for(int j=i;j<=n;j++){
                    Console.Write("*");
                }
                Console.WriteLine();
            }


        }
    }
}